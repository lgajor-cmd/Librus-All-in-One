# Backend — etap do wykonania

Backend jest wymagany w wybranej architekturze, ponieważ aktualny klient `librus-synergia` jest biblioteką Python 3.12+.

## Wymagania docelowe
- Python 3.12+
- FastAPI + Uvicorn
- `librus-synergia`
- PostgreSQL lub SQLite na etapie testów
- szyfrowanie sesji w spoczynku (np. AES-GCM; klucz poza bazą)
- HTTPS (reverse proxy/Caddy)
- osobna instancja `Librus` i osobny cookie jar dla każdego konta

## Kontrakt API proponowany dla aplikacji
- `POST /v1/accounts/{role}/login` — role `parent` lub `student`
- `POST /v1/accounts/{role}/sync` — pobranie zmian
- `GET /v1/accounts/{role}/dashboard`
- `GET /v1/accounts/{role}/grades`
- `GET /v1/accounts/{role}/timetable`
- `GET /v1/accounts/{role}/attendance`
- `GET /v1/accounts/{role}/messages`
- `DELETE /v1/accounts/{role}` — usunięcie powiązania konta

Nie ma tu jeszcze implementacji endpointów. Nie wolno wystawiać atrap jako działającej integracji ani przyjmować prawdziwych haseł przed wdrożeniem TLS, ochrony przed nadużyciami i szyfrowania.
