package pl.domreksio.librusallinone

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101522)
private val Panel = Color(0xFF1B2433)
private val Accent = Color(0xFF8B9CFF)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LibrusApp() }
    }
}

private enum class Profile(val label: String) { PARENT("Rodzic"), STUDENT("Uczeń") }
private enum class Section(val label: String) {
    HOME("Start"), GRADES("Oceny"), TIMETABLE("Plan"), ATTENDANCE("Frekwencja"),
    HOMEWORK("Zadania"), MESSAGES("Wiadomości")
}

@Composable
private fun LibrusApp() {
    var profile by remember { mutableStateOf<Profile?>(null) }
    var loggedIn by remember { mutableStateOf(false) }
    var section by remember { mutableStateOf(Section.HOME) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            when {
                profile == null -> ProfileChooser(onChoose = { profile = it })
                !loggedIn -> LoginScreen(
                    profile = profile!!,
                    onBack = { profile = null },
                    onDemoContinue = { loggedIn = true }
                )
                else -> Dashboard(
                    profile = profile!!,
                    section = section,
                    onSection = { section = it },
                    onSwitch = { loggedIn = false; profile = null }
                )
            }
        }
    }
}

@Composable
private fun ProfileChooser(onChoose: (Profile) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("LIBRUS", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("All-in-One", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Dziennik szkolny w jednym miejscu", color = Muted)
        Spacer(Modifier.height(32.dp))
        Profile.entries.forEach { p ->
            Card(
                onClick = { onChoose(p) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (p == Profile.PARENT) Icons.Default.FamilyRestroom else Icons.Default.School,
                        null, tint = Accent, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Konto ${p.label.lowercase()}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("Osobne dane logowania i sesja", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Rodzic i uczeń mają niezależne profile.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun LoginScreen(profile: Profile, onBack: () -> Unit, onDemoContinue: () -> Unit) {
    var login by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Wróć") }
        Spacer(Modifier.height(24.dp))
        Text("Logowanie", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Profil: ${profile.label}", color = Accent)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(login, { login = it }, label = { Text("Login Synergia") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Hasło Synergia") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(18.dp))
        Button(onClick = {
            notice = "To ekran demonstracyjny. Integracja logowania z Librusem nie jest jeszcze podłączona. Nie wpisuj tutaj prawdziwego hasła."
        }, modifier = Modifier.fillMaxWidth()) { Text("Połącz konto") }
        if (notice.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(notice, color = Color(0xFFFFD18A), fontSize = 13.sp)
        }
        Spacer(Modifier.height(24.dp))
        Text("Dane logowania będą obsługiwane dopiero po wdrożeniu bezpiecznego połączenia HTTPS i szyfrowania sesji.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun Dashboard(profile: Profile, section: Section, onSection: (Section) -> Unit, onSwitch: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Librus All-in-One", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Profil: ${profile.label}", color = Muted, fontSize = 12.sp)
            }
            TextButton(onClick = onSwitch) { Icon(Icons.Default.SwitchAccount, null); Text(" Zmień") }
        }
        NavigationBar(containerColor = Panel) {
            listOf(Section.HOME, Section.GRADES, Section.TIMETABLE).forEach { item ->
                NavigationBarItem(selected = section == item, onClick = { onSection(item) },
                    icon = { Icon(sectionIcon(item), null) }, label = { Text(item.label) })
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text(section.label, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp)) {
                    Text(if (section == Section.HOME) "Witaj!" else "Moduł ${section.label}", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Oczekiwanie na podłączenie synchronizacji Librus.", color = Muted)
                }
            }
            Spacer(Modifier.height(16.dp))
            Section.entries.drop(3).forEach { item ->
                Card(onClick = { onSection(item) }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(sectionIcon(item), null, tint = Accent)
                        Spacer(Modifier.width(12.dp))
                        Text(item.label, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
        Text("Wersja 0.1.0 • interfejs demonstracyjny",
            color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
    }
}

private fun sectionIcon(section: Section) = when (section) {
    Section.HOME -> Icons.Default.Dashboard
    Section.GRADES -> Icons.Default.Grade
    Section.TIMETABLE -> Icons.Default.CalendarMonth
    Section.ATTENDANCE -> Icons.Default.FactCheck
    Section.HOMEWORK -> Icons.Default.MenuBook
    Section.MESSAGES -> Icons.Default.Mail
}
