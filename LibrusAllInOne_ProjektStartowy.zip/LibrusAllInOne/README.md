# Librus All-in-One — projekt startowy

Projekt startowy aplikacji Android dla dwóch niezależnych profili: Rodzic i Uczeń.

## Co zawiera
- natywny interfejs Android (Kotlin + Jetpack Compose),
- ekran wyboru profilu,
- osobne formularze logowania rodzica i ucznia,
- ekran główny z sekcjami: oceny, plan, frekwencja, zadania, wiadomości,
- przygotowany interfejs `LibrusRepository` do podłączenia synchronizacji.

## Ważne — stan projektu
To jest **szkielet aplikacji (MVP UI)**, a nie gotowa, działająca integracja z Librusem ani APK.
Połączenie z Librusem wymaga implementacji adaptera serwerowego i testów na prawdziwych kontach. Nie wpisuj prawdziwych haseł do obecnej wersji — formularze są demonstracyjne i niczego nie wysyłają ani nie zapisują.

## Zalecana architektura
Telefon Android -- HTTPS --> prywatny backend -- osobna sesja --> Librus Synergia

Backend wykorzystuje bibliotekę `librus-synergia` (Python 3.12+). Każdy profil musi mieć własną instancję klienta i własny magazyn sesji. Sesje Librusa są danymi dostępowymi i muszą być szyfrowane po stronie serwera. Hasła nie mogą trafiać do logów ani analityki.

Backend powinien:
1. przyjmować logowanie przez HTTPS,
2. tworzyć oddzielną sesję dla konta rodzica i ucznia,
3. przechowywać odświeżalne dane sesji w szyfrowanej bazie,
4. udostępniać aplikacji tylko dane potrzebne do wyświetlenia,
5. synchronizować zmiany oszczędnie (nie częściej niż co 15 minut),
6. obsługiwać CAPTCHA, błędne hasło, wygaśnięcie sesji, limity i awarie Librusa.

Nie należy wystawiać backendu bez HTTPS, ochrony przed brute-force, ograniczeń dostępu i bezpiecznego zarządzania kluczem szyfrującym.

## Uruchomienie Android Studio
1. Otwórz folder `android/` w Android Studio.
2. Poczekaj na synchronizację Gradle.
3. Uruchom aplikację na emulatorze lub telefonie.
4. W obecnym szkielecie logowanie jest demonstracyjne.

## Następny etap
- implementacja backendu i adaptera `librus-synergia`,
- szyfrowanie i bezpieczne przechowywanie sesji,
- mapowanie odpowiedzi API na modele aplikacji,
- testy rodzica i ucznia osobno,
- powiadomienia push i harmonogram synchronizacji,
- zbudowanie i podpisanie APK.

## Źródła techniczne
- https://pypi.org/project/librus-synergia/
- https://github.com/MichalZaniewicz/librus-synergia
- https://portal.librus.pl/artykuly/jak-zalogowac-sie-do-systemu-synergia-krotki-przewodnik-2

Biblioteka jest nieoficjalna i korzysta z prywatnego API, które może się zmienić. Projekt nie jest powiązany z firmą Librus.
