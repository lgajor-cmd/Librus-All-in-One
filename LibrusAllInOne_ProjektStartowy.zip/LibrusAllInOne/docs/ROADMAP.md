# Plan realizacji

1. Zweryfikować logowanie na osobnym koncie rodzica i ucznia.
2. Zaimplementować backendowy adapter `librus-synergia`.
3. Zdefiniować modele JSON i obsługę błędów poszczególnych sekcji.
4. Podłączyć Androida przez HTTPS; dodać token aplikacji i bezpieczny magazyn.
5. Dodać Room cache i WorkManager (domyślnie synchronizacja co 15–20 minut; Android może opóźniać zadania w tle).
6. Dodać powiadomienia o nowych ocenach/wiadomościach i zmianach planu.
7. Testy bezpieczeństwa, testy regresji po zmianach logowania Librusa.
8. Zbudować podpisany APK.
